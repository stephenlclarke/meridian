from pathlib import Path
import subprocess,os,hashlib,json,datetime,shutil,platform
D=Path(__file__).resolve().parent;E=D/'evidence';S=D/'source';T=D/'target';meta=json.loads((E/'PREPARED.json').read_text());env=dict(os.environ,CARGO_TARGET_DIR=str(T),CARGO_TERM_COLOR='never')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(f):
 with f.open('rb')as h:sha=hashlib.file_digest(h,'sha256').hexdigest()
 return dict(path=str(f),bytes=f.stat().st_size,sha256=sha)
def write(n,d):
 f=E/n
 with f.open('x')as h:h.write(json.dumps(d,indent=2)+'\n');h.flush();os.fsync(h.fileno())
 return pin(f)
def verify():
 rows=json.loads((E/'ROOT-ALL-SOURCE-PINS.json').read_text())
 for name,x in rows.items():
  f=S/name;q=pin(f);assert q['bytes']==x['bytes']and q['sha256']==x['sha256'];assert bool(f.stat().st_mode&0o111)==(x['mode']=='100755')
 return len(rows)
assert verify()==415
review=json.loads((E/'REVIEW.json').read_text());assert review['head']==meta['source']and review['tree']==meta['tree']and review['verdict']=='SOURCE_CLEAR_FINDING_CLOSED'
cargo=shutil.which('cargo');owner={'source':meta['source'],'tree':meta['tree'],'cwd':str(S),'target':str(T),'ownerPID':os.getpid(),'host':platform.system()+' '+platform.machine(),'review':pin(E/'REVIEW.json'),'source':meta['source'],'sourceManifest':pin(E/'SOURCE-BINDING.json'),'rootPacket':pin(E/'ROOT-SOURCE.json'),'runner':pin(Path(__file__).resolve()),'cargoVersion':subprocess.check_output([cargo,'-V'],text=True).strip(),'rustcVersion':subprocess.check_output([shutil.which('rustc'),'-Vv'],text=True).strip()};write('FOCUSED-OWNER.json',owner)
steps=[('CHECK',[cargo,'check','--locked','-p','meridian-geometry','--all-targets']),('TEST',[cargo,'test','--locked','-p','meridian-geometry','--','--nocapture']),('CLIPPY',[cargo,'clippy','--locked','-p','meridian-geometry','--all-targets','--','-D','warnings']),('BUILD',[cargo,'build','--locked','-p','meridian-geometry','--bin','original_five']),('HOST',[shutil.which('python3'),'-B','-m','unittest','discover','-s','crates/meridian-geometry/tools','-p','test_run_original_five.py','-v'])]
terminals=[]
for label,argv in steps:
 f=E/(label.lower()+'.log')
 with f.open('xb')as log:
  child=subprocess.Popen(argv,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT);start={**owner,'label':label,'argv':argv,'pid':child.pid,'startedUTC':now()};sp=write(label+'-START.json',start);print(json.dumps({'event':'ACTUAL_FOCUSED_START','label':label,'start':sp,'pid':child.pid,'argv':argv}),flush=True);status=child.wait()
 terminal={**start,'finishedUTC':now(),'exitCode':status,'rawLog':pin(f)};tp=write(label+'-TERMINAL.json',terminal);terminals.append(tp)
 if status:
  write('FOCUSED-TERMINAL.json',{**owner,'result':'FAIL_STOPPED','failedStage':label,'exitCode':status,'terminals':terminals,'sourceUnchangedFiles':verify(),'wholeFive':'UNRUN_AFTER_FOCUSED_FAILURE'});raise SystemExit(status)
binary=D/'target/debug/original_five';write('FOCUSED-TERMINAL.json',{**owner,'result':'ALL_FOCUSED_GATES_PASS','finishedUTC':now(),'exitCode':0,'terminals':terminals,'sourceUnchangedFiles':verify(),'binary':pin(binary),'wholeFive':'AUTHORIZED_ONE_CHANGED_RUN_NOT_YET_STARTED'});print('ALL_FOCUSED_GATES_PASS',flush=True)
